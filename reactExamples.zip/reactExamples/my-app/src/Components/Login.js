import React, { Component } from 'react';

class Login extends Component {
 
  render() {
      
    return (
      <div>
          <h2>Login</h2>
       </div>
    );
  }
}

export default Login;
