import React, { Component } from 'react';


class Editemp extends Component {
  
  render() {
    return (
      <div>
         
      </div>
    );
  }
}

export default Editemp;
