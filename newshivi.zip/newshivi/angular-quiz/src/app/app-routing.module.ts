import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import{LoginComponent} from './login/login.component';
import{RulesComponent} from'./rules/rules.component';
import{QuestionsComponent} from './questions/questions.component'

export const routes: Routes = [
  {path:'',redirectTo:'/login',pathMatch:'full'},
  { path: 'login', component: LoginComponent },
  {path:'rules',component:RulesComponent},
 //{path:'questions',component:QuestionsComponent},
  //{path:'questions/:id',component:QuestionsComponent},
  
];

@NgModule({
imports: [ RouterModule.forRoot(routes) ],
exports: [ RouterModule ],
declarations: []
})
export class AppRoutingModule { }
