import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finalpage',
  templateUrl: './finalpage.component.html',
  styleUrls: ['./finalpage.component.css']
})
export class FinalpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
