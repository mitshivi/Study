import { Component, OnInit } from '@angular/core';
import{LoginService} from '../login.service';
import {RulesComponent} from'../rules/rules.component';
//import{} from
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private loginData:LoginService) { }
  data:any;
  username:string[];
  password:string[];
  //temp:number=0;
  ngOnInit() {

  this.loginData.getData().subscribe(info=>{this.data=info;console.log(this.data)})
}

login(){
  for(var i=0;i<this.data.length;i++)
  {
    if(this.username==this.data[i].userid)
    {
      if(this.password==this.data[i].password)
      {
        console.log('login Successful');
        alert('You are Sucessfully logged in');
       // this.route.navigate(['/rules']);
      //  this.temp=1;
        break;
      }
      else{
        alert('you entered wrong password');
        break;
      }
    }
    
  }
}


  

}
