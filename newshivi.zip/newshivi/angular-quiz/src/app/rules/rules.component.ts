import { Component, OnInit } from '@angular/core';
import {QuestionsComponent} from '../questions/questions.component'
@Component({
  selector: 'app-rules',
  templateUrl: './rules.component.html',
  styleUrls: ['./rules.component.css']
})
export class RulesComponent implements OnInit {

  constructor() { }
  cont:number=0;
  ngOnInit() {
  }
  
  continue(){
    let a=confirm("Are you sure you want to continue?");
    if(a)
    {
      this.cont=1;
    }
    else{
      this.cont=0;
    }
    
  }

}
