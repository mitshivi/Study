import { Component, OnInit } from '@angular/core';
import {QuestionsService} from '../questions.service';
import{FinalpageComponent} from '../finalpage/finalpage.component'
@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {

  constructor(private quesData:QuestionsService) { }
  info:any;
  data:any;
  temp:number=0;
  selectedans:any=0;
  i:number=1;
  score:number=0;
  ans:any;
  finalPage:number=0;
  ngOnInit() {  
  this.quesData.getQues("/assets/questions.json").subscribe(data=>{this.data=data;console.log(this.data)});
 
}

  heading:string;
  qno:number;
  queOptions:string[]; 
  selected:string;
  correct:number=0;
  queAns:any;
  tickedAnswer:string;
  answerArray:any=[];
  ansUser:string[]=[];
  quesIndex:number;
  kuch:number=0;

  openQues(b:number){
  this.heading=this.data[b].Q;
  this.qno=this.data[b].id;
  this.queOptions=this.data[b].options;
  this.queAns=this.data[b].answer;
  this.quesIndex=b;
}
checkans(ty:string){
 this.ansUser[this.quesIndex]=ty;
 console.log(this.ansUser);
}
submitAns()
{
  let a=confirm("Are you sure you want to Submit the Test?");
  if(a){
  for(let i=0;i<this.data.length;i++)
  {
    this.answerArray.push(this.data[i].answer);
  }
  console.log(this.answerArray);
  console.log(this.ansUser);
  for(let b=0;b<this.ansUser.length;b++){
  if(this.ansUser[b]==this.answerArray[b]){
   this.correct++;
   
  }
}
alert("your score is "+this.correct);
this.correct=0;
this.kuch=1;
}

}
    
}



































/*  result(){
  let a=confirm("Do u really want to submit the test?");
  if(a)
  {
    alert("Your total score is "+this.score);
  }  
  }*/


  /*selectedkuch(ty:any){
    this.selectedans=ty;
    console.log(this.selectedans);
}

  callNext(){
    if(this.selectedans==0)
    {
      alert("please select a valid option");
    }
    else{
      this.ans=this.info[0].answer;
      console.log("the answer is "+this.ans);
      if(this.ans==this.selectedans)
      {
        this.score++;
        //alert(this.score);
      }
      this.selectedans=0;
      if(this.i<5)
      {
      this.i++;
      this.quesData.getQues("/assets/ques"+this.i+".json").subscribe(info=>{this.info=info;console.log(this.info)});
      this.ans=this.info[0].answer;
    }

    else{
      
      let a=confirm("The quiz is completed, You may submit Now");
      if(a)
      {
      this.temp=1;
      }
    }
    }
  }*/