import { Component } from '@angular/core';
import {InsuranceTypeComponent} from './insurance-type/insurance-type.component'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'insurance-management-system';
}
