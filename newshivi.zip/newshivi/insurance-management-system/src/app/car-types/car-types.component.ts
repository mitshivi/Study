import { Component, OnInit } from '@angular/core';
import {InsurancetypeService} from '../insurancetype.service';
declare var $:any;
@Component({
  selector: 'app-car-types',
  templateUrl: './car-types.component.html',
  styleUrls: ['./car-types.component.css']
})
export class CarTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  

}
