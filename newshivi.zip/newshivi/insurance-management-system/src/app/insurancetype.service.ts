import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { TYPES } from './mock-data';
import { Observable, of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})

export class InsurancetypeService {

constructor(private _http:HttpClient){}

getComponent(){
  return this._http.get('assets/Car Insurance.json');
}

/*getComponent(x){
  return this._http.get(x);
}*/
  
}
