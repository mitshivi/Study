import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { InsuranceTypeComponent } from './insurance-type/insurance-type.component';
import { CarTypesComponent } from './car-types/car-types.component';

@NgModule({
  declarations: [
    AppComponent,
    InsuranceTypeComponent,
    CarTypesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})


export class AppModule { 

}
