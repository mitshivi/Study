export const TYPES:any[]=["HomeInsurance","CarInsurance","LifeInsurance"];
export const Car :any[]=["Baleno","HondaCity","SwiftDezire","Brezza"];
export const Life:any[]=["Term Insurance","Life Insurance","Some Insurance"];
export const Home:any[]=["Full Insurance","Complete Cover","some Home Insurance"];