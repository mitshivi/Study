import { TestBed, inject } from '@angular/core/testing';

import { InsurancetypeService } from './insurancetype.service';

describe('InsurancetypeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InsurancetypeService]
    });
  });

  it('should be created', inject([InsurancetypeService], (service: InsurancetypeService) => {
    expect(service).toBeTruthy();
  }));
});
