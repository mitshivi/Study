/*import { Component, OnInit } from '@angular/core';
import {InsurancetypeService} from '../insurancetype.service';
import{CarTypesComponent} from '../car-types/car-types.component'
declare var $:any;
@Component({
  selector: 'app-insurance-type',
  templateUrl: './insurance-type.component.html',
  styleUrls: ['./insurance-type.component.css']
})
export class InsuranceTypeComponent implements OnInit {

types:any[];
components:any[];
info:any[];
value:any[];
selected:any;
temp:number=0;
constructor(private typeService: InsurancetypeService) { }


ngOnInit() {
this.typeService.getComponent("/assets/insurance.json").subscribe(products=>this.info=products[0].Insurance);
}

abc():void{
  if(this.temp<2){
    console.log(this.temp);
this.typeService.getComponent(`/assets/${this.selected}.json`).subscribe(products=>this.info=products[0].option);
this.temp++;
  }
  else{
    console.log("holla");
  }
}

xyz(ty:any):void{
  this.selected=ty;
  alert(this.selected);
}
 
}*/






/*[{"CarInsurance":["Baleno","TATA Nexon","Jeep Compass","Brezza"]}]*/


 

































































import { Component, OnInit } from '@angular/core';
import {InsurancetypeService} from '../insurancetype.service';
import{CarTypesComponent} from '../car-types/car-types.component'
declare var $:any;
@Component({
  selector: 'app-insurance-type',
  templateUrl: './insurance-type.component.html',
  styleUrls: ['./insurance-type.component.css']
})
export class InsuranceTypeComponent implements OnInit {

types:any[];
components:any[];
info:any[];
value:any[];
selected:any;
constructor(private typeService: InsurancetypeService) { }

getComponent():void{
  this.typeService.getComponent().subscribe(components =>this.info=components[0].option);
}


ngOnInit() {
this.getComponent();
}

/*abc():void{
if(this.selected==this.info[1])
{
  alert('Congratulations you have selected car Insurance');
  this.getComponent();
  console.log(this.value);
  this.info=this.value;

}
if(this.selected==this.info[2])
{
  alert('Congratulations you have selected Life insurance');
  this.getComponent();
  console.log(this.value);
  this.info=this.value;

}
if(this.selected==this.info[0])
{
  alert('Congratulations you have selected Home Insurance');
  this.getComponent();
  console.log(this.value);
  this.info=this.value;

}

}

xyz(ty:any):void{
  console.log(this.info[1]);
  this.selected=ty;
  console.log(this.selected);
}*/



 
}









 /* constructor() { }
  info:any[];
  ngOnInit() {
    $.get('src/app/insurance-type/insurance.json',(d,r)=>{
      this.info=d.type;
      console.log(this.info);
    })
  }*/
  
  
  
//adding the json data
//type:string[]=["Home Insurance","Car insurance", "other Insurance"];








/* getTypes(): void {
  this.types = this.typeService.getTypes();
  console.log(this.types);
  this.info=this.types;
  console.log(this.info);
}*/  