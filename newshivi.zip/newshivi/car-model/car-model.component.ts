import { Component,OnInit} from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-car-model',
  templateUrl: './car-model.component.html',
  styleUrls: ['./car-model.component.css']
})

export class CarModelComponent {
  title:string='Car Models';
  mod1:string;
  mod2:string;
  mod3:string;
  mod4:string;
  ngOnInit(){
  $.get('src/app/car-model/car-model.json',(d,r)=>{
      this.mod1=d.model[0];
      this.mod2=d.model[1];
      this.mod3=d.model[2];
      this.mod4=d.model[3];
    })
  }
  
}
