let str:string;

str.substring(2,3);


let str2;

(<string>str2).length;

(str2 as string).length;