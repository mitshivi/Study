var str;
str.substring(2, 3);
var str2;
str2.length;
str2.length;
