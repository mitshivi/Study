class television{
    manufacturer:string;
    size:number;
    maxChannels:number;
    price:number;
    displayType:string;
    constructor(man:string,s:number,mchannel:number,p:number,dp:string)
    {
        this.manufacturer=man;
        this.size=s;
        this.maxChannels=mchannel;
        this.price=p;
        this.displayType=dp;
    }
    on(){
         //create a new television object
       

    }

}