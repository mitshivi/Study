var calcSum=function(...num:number[]):void{
    var sum=num.reduce(()a,b=>a+b);
    
}

////
var total=[0,1,2,3]=num.reduce(()a,b=>a+b)