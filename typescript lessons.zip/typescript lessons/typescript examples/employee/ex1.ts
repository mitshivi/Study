class employee{
    firstName:string;
    lastName:string;
    age:number;
    constructor(fName:string,lName:string,age:number){
        this.age=age;
        this.firstName=fName;
        this.lastName=lName;
    }
    setName (fName,lName){
     this.firstName=fName;
     this.lastName=lName;
    }
    getName(){
        return this.firstName+this.lastName;
    }


}

let emp1=new employee();
let emp2=new employee();


