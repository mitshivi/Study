var employee = /** @class */ (function () {
    function employee(fName, lName, age) {
        this.age = age;
        this.firstName = fName;
        this.lastName = lName;
    }
    employee.prototype.setName = function (fName, lName) {
        this.firstName = fName;
        this.lastName = lName;
    };
    employee.prototype.getName = function () {
        return this.firstName + this.lastName;
    };
    return employee;
}());
var emp1 = new employee();
var emp2 = new employee();
