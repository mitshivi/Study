var app=require('http');
var fr=require('fs');

var x=(req,res)=>{
    data=fr.readFileSync('empdata.json');
    a=res.write(JSON.parse(data));
    console.log("something good");
    res.end(); 
}
app.createServer(x).listen(678,()=>{
    console.log("Running Successfully ");
})