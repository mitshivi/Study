var http=require('http');

//var fr =require('fr');
var fs=require('fs');
/*http.createServer(
    function(req,res){
         res.writeHead(200,{'Content-Type':'text/html'});
         res.write("<input type='button' value='nothing'>");
        /* res.writeHead(200,{'Content-Type':'application/json'});
         res.write({"key":"value"}); */
         /*res.end();
    }
).listen(12345,()=>{console.log("Running on ")});

function f2(){
    var jsondata='{"name":"kuchbhi","age":45}';
    var js=JSON.stringify(jsondata);
    fs.writeFileSync('hello.json',jsondata);
    console.log(JSON.parse(fs.readFileSync('hello.json')));
}
f2();*/
//reading and writing in the file



var x=(req,res)=>{
    res.write(JSON.parse(fs.readFileSync('hello.json')))
    res.write(JSON.stringify(x));
    res.end();
}
http.createServer(x).listen(1234,()=>{
    console.log("Running");
})

