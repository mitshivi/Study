var evt=require('events');

var evt1=new evt.EventEmitter();


function l1(){
    console.log("Listener One");
}

evt1.on('evt1',l1);

evt1.emit('evt1');