function curr(){
    console.log("curr service");

}

function payment(msg){
    if(msg<0)
    console.log("unsuccessful");
    else
    curr();
}